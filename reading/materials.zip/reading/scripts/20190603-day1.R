# this is a comment
1

print("Hello world!") # print some text

3 + 4

sqrt(90)

7^2

# iris